<template>
    <item-form> </item-form>
</template>

<script>
import ItemForm from '../itemform/ItemForm.vue'
export default {
  name:'ItemCreate',
  components: { ItemForm },

}
</script>

<style>

</style>