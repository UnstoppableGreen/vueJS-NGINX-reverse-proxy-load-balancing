<template>
    <order-form> </order-form>
</template>

<script>
import OrderForm from '../orderform/OrderForm.vue'
export default {
  name:'OrderCreate',
  components: { OrderForm },

}
</script>

<style>

</style>