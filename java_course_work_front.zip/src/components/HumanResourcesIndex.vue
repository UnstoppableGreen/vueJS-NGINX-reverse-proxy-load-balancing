<template>
  <float-menu
    :position="'top left'"
    :dimension="50"
    :menu-data="items"
    menu-style="accordion"
    :on-selected="handleSelection"
  >
    Menu
  </float-menu>
  <Suspense v-if=showDivisions>
    <template #default>
      <list-division />
    </template>
    <template #fallback>
      <p>Loading...</p>
    </template>
  </Suspense>
  <Suspense v-if=createDivision>
    <template #default>
      <division-create />
    </template>
    <template #fallback>
      <p>Loading...</p>
    </template>
  </Suspense>
</template>

<script>
import { FloatMenu } from "vue-float-menu";
import "vue-float-menu/dist/vue-float-menu.css";
import { defineAsyncComponent } from 'vue'

export default {
  
  components: {
    FloatMenu,
    ListDivision: defineAsyncComponent(() =>
      import('../components/divisions/ListDivision.vue')
    ),
    DivisionCreate: defineAsyncComponent(() =>
      import('../components/divisionform/DivisionCreate.vue')
    )
  },
  setup() {

  },
  data() {
    let showDivisions=false;
    let createDivision=false;
    const handleSelection = (selectedItem) => {
      console.log(selectedItem);
      if (selectedItem=="Показать отделы") {this.showDivisions=!this.showDivisions;}
      if (selectedItem=="Создать отдел") {this.createDivision=!this.createDivision;}
    };
    return {
      handleSelection, showDivisions, createDivision,
      items: [
        { name: "Создать справочники",
        subMenu: {
            name: "create-refence",
            items: [{ name: "Создать мед. организацию" }, { name: "Создать должность" }, { name: "Создать отдел" }, { name: "Создать тип нетрудоспособности" },
            { name: "Создать отметку для листа" }, { name: "Создать режим работы" }],
          },
         
        },
        {divider: true},
        {
          name: "Посмотреть справочники",
          subMenu: {
            name: "view-references",
            items: [{ name: "Показать мед. организации" }, { name: "Показать должности" }, { name: "Показать отделы" }, { name: "Показать типы нетрудоспособности" },
            { name: "Показать отметки для листа" }, { name: "Показать режимы работы" }],
          },
        },
        {divider: true},
        {
          name: "Больничные листы",
          subMenu: {
            name: "sickLeaves",
            items: [{ name: "Создать больничный лист" }, { name: "Посмотреть больничные листы" }],
          },
        },
        {divider: true},
        {
          name: "Командировки",
          subMenu: {
            name: "sickLeaves",
            items: [{ name: "Создать командировку" }, { name: "Посмотреть командировки" }],
          },
        },
        {divider: true},
        {
          name: "Листы учета рабочего времени",
          subMenu: {
            name: "sickLeaves",
            items: [{ name: "Создать лист учета рабочего времени" }, { name: "Посмотреть листы учета рабочего времени" }],
          },
        },
        {divider: true},
        {
          name: "Работники",
          subMenu: {
            name: "sickLeaves",
            items: [{ name: "Создать работника" }, { name: "Посмотреть работников" }],
          },
        },
        {divider: true},
        {
          name: "Open Recent"
        },
        {
          name: "Save",
        }
      ],
    };
  },
};
</script>