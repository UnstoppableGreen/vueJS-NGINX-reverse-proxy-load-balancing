<template>
    <supplier-form> </supplier-form>
</template>

<script>
import SupplierForm from '../supplierform/SupplierForm.vue'
export default {
  name:'SupplierCreate',
  components: { SupplierForm },

}
</script>

<style>

</style>