<template>
    <Shipment-form> </Shipment-form>
</template>

<script>
import ShipmentForm from '../shipmentform/ShipmentForm.vue'
export default {
  name:'ShipmentCreate',
  components: { ShipmentForm },

}
</script>

<style>

</style>