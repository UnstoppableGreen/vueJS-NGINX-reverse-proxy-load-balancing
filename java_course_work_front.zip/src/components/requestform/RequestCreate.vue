<template>
    <request-form> </request-form>
</template>

<script>
import RequestForm from '../requestform/RequestForm.vue'
export default {
  name:'RequestCreate',
  components: { RequestForm },

}
</script>

<style>

</style>