<template>
    <carrier-form> </carrier-form>
</template>

<script>
import CarrierForm from '../carrierform/CarrierForm.vue'
export default {
  name:'CarrierCreate',
  components: { CarrierForm },

}
</script>

<style>

</style>