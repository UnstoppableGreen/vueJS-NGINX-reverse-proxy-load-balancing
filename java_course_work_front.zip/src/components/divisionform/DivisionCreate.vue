<template>
    <division-form> </division-form>
</template>

<script>
import DivisionForm from '../divisionform/DivisionForm.vue'
export default {
  name:'DivisionCreate',
  components: { DivisionForm },

}
</script>

<style>

</style>